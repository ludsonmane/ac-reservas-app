'use client';

import React from 'react';
import dayjs from 'dayjs';
import {
  API_BASE,
  apiPost,
  fetchUnitsOptions,
  fetchAreasAvailability, // <- usa este nome do lib/api.ts
  type UnitOption,
  type AreaAvailability,
} from '../lib/api';

/* --------------------------------- Utils --------------------------------- */
const todayYMD = () => dayjs().format('YYYY-MM-DD');

// Slots: tarde (12:00–17:00) e noite (17:30–22:00)
const TIME_SLOTS: string[] = [
  '12:00','12:30','13:00','13:30','14:00','14:30','15:00','15:30','16:00','16:30','17:00',
  '17:30','18:00','18:30','19:00','19:30','20:00','20:30','21:00','21:30','22:00',
];

type ReservForm = {
  fullName: string;
  email?: string;
  phone?: string;
  notes?: string;
};

export default function ReservarPage() {
  /* Passo 1: seleção base */
  const [units, setUnits] = React.useState<UnitOption[]>([]);
  const [unitId, setUnitId] = React.useState<string>('');
  const [dateISO, setDateISO] = React.useState<string>(todayYMD());
  const [timeHHmm, setTimeHHmm] = React.useState<string>('');
  const [people, setPeople] = React.useState<number>(1);
  const [kids, setKids] = React.useState<number>(0);
  const totalGuests = people + kids; // ✅ conta crianças uma única vez

  /* Passo 2: áreas disponíveis (por PERÍODO) */
  const [areas, setAreas] = React.useState<AreaAvailability[]>([]);
  const [areasLoading, setAreasLoading] = React.useState(false);
  const [areaId, setAreaId] = React.useState<string>('');

  /* Passo 3: dados do cliente */
  const [form, setForm] = React.useState<ReservForm>({ fullName: '' });
  const [saving, setSaving] = React.useState(false);

  /* Resultado */
  const [createdId, setCreatedId] = React.useState<string>('');
  const [createdCode, setCreatedCode] = React.useState<string>('');

  /* ------------------------------ Carrega units ----------------------------- */
  React.useEffect(() => {
    let cancel = false;
    (async () => {
      try {
        const list = await fetchUnitsOptions();
        if (!cancel) setUnits(list);
      } catch {
        if (!cancel) setUnits([]);
      }
    })();
    return () => { cancel = true; };
  }, []);

  /* -------- Disponibilidade POR PERÍODO (unitId + date + time obrigatórios) ------- */
  React.useEffect(() => {
    let cancel = false;

    async function loadAreas() {
      if (!unitId || !dateISO || !timeHHmm) {
        setAreas([]);
        return;
      }
      setAreasLoading(true);
      try {
        const list = await fetchAreasAvailability({ unitId, date: dateISO, time: timeHHmm });
        if (!cancel) setAreas(list);
      } catch {
        if (!cancel) setAreas([]);
      } finally {
        if (!cancel) setAreasLoading(false);
      }
    }

    loadAreas();
    return () => { cancel = true; };
  }, [unitId, dateISO, timeHHmm]);

  /* --- Se a área escolhida ficar sem vagas (ou total exceder) após recarregar, limpar seleção --- */
  React.useEffect(() => {
    if (!areaId) return;
    const found = areas.find(a => a.id === areaId);
    const remaining = found?.remaining ?? found?.available ?? 0;
    if (!found || remaining <= 0 || totalGuests > remaining) setAreaId('');
  }, [areas, areaId, totalGuests]);

  /* --------------------------------- Submit -------------------------------- */
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (saving) return;

    if (!unitId) return alert('Selecione a unidade.');
    if (!dateISO) return alert('Selecione a data.');
    if (!timeHHmm) return alert('Selecione o horário.');
    if (!areaId) return alert('Selecione a área.');
    if (!form.fullName.trim()) return alert('Informe o nome completo.');

    // ✅ validação client-side: não deixa exceder capacidade do período
    const chosen = areas.find(a => a.id === areaId);
    const remaining = chosen ? (chosen.remaining ?? chosen.available ?? 0) : 0;
    if (remaining <= 0) return alert('A área escolhida não possui vagas neste período.');
    if (totalGuests > remaining) {
      return alert(
        `Você selecionou ${totalGuests} pessoa(s), mas só há ${remaining} vaga(s) para este período.`
      );
    }

    const reservationISO = dayjs(`${dateISO}T${timeHHmm}:00`).toISOString();

    setSaving(true);
    try {
      const payload = {
        fullName: form.fullName.trim(),
        email: form.email?.trim() || null,
        phone: form.phone?.trim() || null,
        notes: form.notes?.trim() || null,
        people,        // ✅ adultos
        kids,          // ✅ crianças (não será somado novamente no servidor)
        reservationDate: reservationISO,
        unitId,
        areaId,
        source: 'site',
      };

      const res = await apiPost<{ id: string; reservationCode: string }>(
        '/v1/reservations/public',
        payload,
        { noCredentials: true }
      );

      setCreatedId(res.id);
      setCreatedCode(res.reservationCode);
    } catch (err: any) {
      const msg = err?.message || 'Falha ao criar a reserva.';
      alert(msg);
    } finally {
      setSaving(false);
    }
  }

  /* ----------------------------- Boarding pass ----------------------------- */
  if (createdId) {
    const qrUrl = `${API_BASE}/v1/reservations/${createdId}/qrcode`;
    return (
      <section className="container mx-auto max-w-2xl px-4 py-6">
        <div className="border rounded-lg p-4">
          <h1 className="text-2xl font-semibold mb-3">Reserva confirmada 🎉</h1>
          <p className="text-sm text-gray-600 mb-1">Código da reserva:</p>
          <p className="text-3xl font-mono font-bold tracking-wider mb-4">{createdCode}</p>

          <div className="flex items-center gap-4">
            <img
              src={qrUrl}
              alt="QR da reserva"
              className="h-40 w-40 rounded border"
              crossOrigin="anonymous"
            />
            <div className="text-sm text-gray-700">
              <p>Apresente este QR no check-in.</p>
              <p className="mt-2">
                Data: <b>{dayjs(`${dateISO}T${timeHHmm}`).format('DD/MM/YYYY HH:mm')}</b>
              </p>
              <p>
                Pessoas: <b>{people}</b>{kids ? ` (+${kids} crianças)` : ''}
              </p>
            </div>
          </div>

          <button
            className="mt-6 inline-flex items-center px-4 py-2 rounded bg-green-600 text-white hover:bg-green-700"
            onClick={() => {
              setCreatedId('');
              setCreatedCode('');
            }}
          >
            Fazer outra reserva
          </button>
        </div>
      </section>
    );
  }

  /* ---------------------------------- Form --------------------------------- */
  return (
    <section className="container mx-auto max-w-3xl px-4 py-6">
      <h1 className="text-2xl font-semibold mb-4">Reservar</h1>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Passo 1: Unidade / Pessoas / Data / Hora */}
        <div className="border rounded-lg p-4 space-y-3">
          <h2 className="font-semibold">1) Selecione os dados básicos</h2>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <label className="md:col-span-2">
              <span className="block text-sm mb-1">Unidade*</span>
              <select
                className="w-full border rounded p-2"
                value={unitId}
                onChange={(e) => { setUnitId(e.target.value); setAreaId(''); }}
              >
                <option value="">Selecione...</option>
                {units.map(u => (
                  <option key={u.id} value={u.id}>{u.name}</option>
                ))}
              </select>
            </label>

            <label>
              <span className="block text-sm mb-1">Pessoas*</span>
              <input
                type="number"
                min={1}
                className="w-full border rounded p-2"
                value={people}
                onChange={(e) => setPeople(Math.max(1, parseInt(e.target.value || '1', 10)))}
              />
            </label>

            <label>
              <span className="block text-sm mb-1">Crianças</span>
              <input
                type="number"
                min={0}
                className="w-full border rounded p-2"
                value={kids}
                onChange={(e) => setKids(Math.max(0, parseInt(e.target.value || '0', 10)))}
              />
            </label>

            <label>
              <span className="block text-sm mb-1">Data*</span>
              <input
                type="date"
                className="w-full border rounded p-2"
                value={dateISO}
                onChange={(e) => { setDateISO(e.target.value); setAreaId(''); }}
              />
            </label>

            <label>
              <span className="block text-sm mb-1">Horário*</span>
              <select
                className="w-full border rounded p-2"
                value={timeHHmm}
                onChange={(e) => { setTimeHHmm(e.target.value); setAreaId(''); }}
              >
                <option value="">Selecione...</option>
                {TIME_SLOTS.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </label>
          </div>

          <div className="text-xs text-gray-600">
            <div>Selecionados: <b>{totalGuests}</b> pessoa(s) ({people} adulto(s){kids ? ` + ${kids} criança(s)` : ''}).</div>
            <div>Disponíveis = capacidade do turno − reservas confirmadas para o mesmo período.</div>
          </div>
        </div>

        {/* Passo 2: Áreas (por período) */}
        <div className="border rounded-lg p-4">
          <h2 className="font-semibold mb-3">2) Escolha a área</h2>

          {!unitId || !dateISO || !timeHHmm ? (
            <p className="text-sm text-gray-600">Selecione unidade, data e horário para ver as áreas disponíveis.</p>
          ) : areasLoading ? (
            <p className="text-sm text-gray-600">Carregando áreas…</p>
          ) : areas.length === 0 ? (
            <p className="text-sm text-gray-600">Nenhuma área disponível para esse período.</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {areas.map(a => {
                const remaining = a.remaining ?? a.available ?? 0;
                const exceeds = totalGuests > remaining;
                const disabled = remaining <= 0 || exceeds;
                return (
                  <button
                    key={a.id}
                    type="button"
                    disabled={disabled}
                    onClick={() => setAreaId(a.id)}
                    className={`text-left border rounded p-3 transition ${
                      areaId === a.id ? 'ring-2 ring-green-600' : ''
                    } ${disabled ? 'opacity-50 cursor-not-allowed' : 'hover:bg-gray-50'}`}
                    title={exceeds ? `Você selecionou ${totalGuests} e só restam ${remaining}` : undefined}
                  >
                    <div className="flex items-center gap-3">
                      {a.photoUrl ? (
                        <img
                          src={a.photoUrl}
                          alt={a.name}
                          className="h-16 w-16 rounded object-cover border"
                          crossOrigin="anonymous"
                        />
                      ) : (
                        <div className="h-16 w-16 rounded bg-gray-100 border" />
                      )}
                      <div>
                        <div className="font-medium">{a.name}</div>
                        <div className="text-sm text-gray-600">
                          Disponíveis: {remaining}
                          {exceeds && (
                            <span className="ml-2 text-red-600 font-medium">
                              (excede sua seleção)
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Passo 3: Dados pessoais */}
        <div className="border rounded-lg p-4 space-y-3">
          <h2 className="font-semibold">3) Seus dados</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <label className="md:col-span-2">
              <span className="block text-sm mb-1">Nome completo*</span>
              <input
                className="w-full border rounded p-2"
                value={form.fullName}
                onChange={(e) => setForm(s => ({ ...s, fullName: e.target.value }))}
                placeholder="Ex.: Maria Silva"
              />
            </label>
            <label>
              <span className="block text-sm mb-1">E-mail</span>
              <input
                type="email"
                className="w-full border rounded p-2"
                value={form.email || ''}
                onChange={(e) => setForm(s => ({ ...s, email: e.target.value }))}
                placeholder="voce@exemplo.com"
              />
            </label>
            <label>
              <span className="block text-sm mb-1">Telefone</span>
              <input
                className="w-full border rounded p-2"
                value={form.phone || ''}
                onChange={(e) => setForm(s => ({ ...s, phone: e.target.value }))}
                placeholder="(00) 00000-0000"
              />
            </label>
            <label className="md:col-span-2">
              <span className="block text-sm mb-1">Observações</span>
              <textarea
                rows={3}
                className="w-full border rounded p-2"
                value={form.notes || ''}
                onChange={(e) => setForm(s => ({ ...s, notes: e.target.value }))}
                placeholder="Algo que devamos saber?"
              />
            </label>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center px-5 py-2 rounded bg-green-600 text-white hover:bg-green-700 disabled:opacity-60"
          >
            {saving ? 'Enviando…' : 'Confirmar reserva'}
          </button>
        </div>
      </form>
    </section>
  );
}
